# Hospital

## Installation

Make sur to have yarn installed.
(Has not been tested with NPM, but should work also.)

All instructions are in the hospital.pdf