import {PatientsRegister} from './patientsRegister';

export class Quarantine {

    private static readonly NOT_IMPLEMENTED_MESSAGE = 'Error!!! Its not implemented properly';
    private static PATIENTS_LIST_ERROR = 'There are no Patients in the hospital';
    private static DRUGS_ERROR = 'No Drugs Available';
    private static REPORT_ERROR = 'There is no report available';
    private reportedPatients = {};
    private drugsGiven:Array<string> = [];
    

    constructor(patients: PatientsRegister) {    
        try {
            this.reportedPatients = patients;
        } catch (error) {
            throw new Error(Quarantine.PATIENTS_LIST_ERROR);
        }   
    }

    public setDrugs(drugs: Array<string>): void {
        this.drugsGiven = drugs
        this.wait40Days()
    }

    public wait40Days(): void {
        if(this.reportedPatients) {
            let patients: PatientsRegister = this.reportedPatients;
            const drugs = this.drugsGiven
            
            Object.keys(patients).forEach(function(key) {                
                const keyNumber = patients[key]
                for(let i=0;i<keyNumber;i++) {                    
                    switch (key) {
                        case 'F':                            
                            if(['As', 'P'].every(i => drugs.includes(i))) {
                                patients = {
                                    ...patients,
                                    'X': patients['X'] ? patients['X']+1 : 1,
                                    'F': patients[key]-1
                                }
                            } else 
                            if(['As', 'P'].some(i => drugs.includes(i))) {
                                patients = {
                                    ...patients,
                                    'H': patients['H'] ? patients['H']+1 : 1,
                                    'F': patients[key]-1
                                }
                            }
                            else {
                                patients = {
                                    ...patients
                                }
                            }
                            
                            break;
                        
                        case 'H':
                            if(['As', 'P'].every(i => drugs.includes(i))) {
                                patients = {
                                    ...patients,
                                    'X': patients['X'] ? patients['X']+1 : 1,
                                    'H': patients[key]-1
                                }
                            } 

                            if(['An', 'I'].every(i => drugs.includes(i))) {
                                patients = {
                                    ...patients,
                                    'F': patients['F'] ? patients['F']+1 : 1,
                                    'H': patients[key]-1
                                }
                            }

                            else {
                                patients = {
                                    ...patients
                                }
                            }

                            break;

                            case 'D':
                                if(['P', 'As'].every(i => drugs.includes(i))) {
                                    patients = {
                                        ...patients,
                                        'X': patients['X'] ? patients['X']+1 : 1,
                                        'D': patients[key]-1
                                    }
                                }

                                if(!drugs.includes('I')) {
                                    patients = {
                                        ...patients,
                                        'X': patients['X'] ? patients['X']+1 : 1,
                                        'D': patients[key]-1
                                    }
                                }

                                else {
                                    patients = {
                                        ...patients
                                    }
                                }
                                break;
                            
                            case 'T':
                                if(['P', 'As'].every(i => drugs.includes(i))) {
                                    patients = {
                                        ...patients,
                                        'X': patients['X'] ? patients['X']+1 : 1,
                                        'T': patients[key]-1
                                    }
                                }

                                if(drugs.includes('An')) {
                                    patients = {
                                        ...patients,
                                        'H': patients['H'] ? patients['H']+1 : 1,
                                        'T': patients[key]-1
                                    }
                                }

                                else {
                                    patients = {
                                        ...patients
                                    }
                                }
                                break;
                            
                        default:
                            patients = {
                                ...patients
                            }
                    }   
                }
            });
            this.reportedPatients = patients;
        } else {
            throw new Error(Quarantine.NOT_IMPLEMENTED_MESSAGE);
        }
    }

    public report(): PatientsRegister {
        if(this.reportedPatients) {
            return this.reportedPatients
        }else {
            throw new Error(Quarantine.REPORT_ERROR);
        }
    }
}
