export {Quarantine} from './quarantine';
export {PatientsRegister} from './patientsRegister';