export interface PatientsRegister {
    [key: string]: number
}