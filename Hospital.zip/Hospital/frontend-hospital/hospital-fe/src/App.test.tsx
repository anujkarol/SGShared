import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

test('display top header', () => {
  render(<App />);
  const linkElement = screen.getByText(/Hospital Simulation System/i);
  expect(linkElement).toBeInTheDocument();
});

test('First Button click to get data from server', () => {
  const getData = jest.fn()
  render(<button onClick={() => getData()}>Click Here!!</button>);  
  fireEvent.click(screen.getByText(/Click Here!!/i));
  expect(getData).toHaveBeenCalledTimes(1);
});
