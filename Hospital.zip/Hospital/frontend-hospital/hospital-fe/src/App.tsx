import React, { useState } from 'react';
import {Quarantine} from 'hospital-lib';
import './App.css';

function App() {

  const [patientsRegister, getPatientsRegister] = useState('')
  const [drugNames, getDrugsName] = useState('')
  const [simulationResult, setSimulationResult] = useState({})
  const [patientInitialState, setpatientInitialState] = useState<string[]>([])
  const [patientOutputState, setPatientOutputState] = useState([{}])
  const [simulationRecord,showSimulationRecord] = useState(false)

  const getData = () => {
    Promise.all([
      fetch('http://localhost:7200/patients'),
      fetch('http://localhost:7200/drugs')
    ]).then(function (responses) {
      // Get a JSON object from each of the responses
      return Promise.all(responses.map(function (response) {
        return response.json();
      }));
    }).then(function (data:any[]) {
      getPatientsRegister(data[0])
      setpatientInitialState(patientInitialState => [...patientInitialState, data[0]])
      getDrugsName(data[1])
      setSimulationResult({})
      showSimulationRecord(false)
    }).catch(function (error) {
      console.log('Error in the API Call', error);
    });
  }

  // To make patientsRegister string into array
  const patientNameArr = patientsRegister.split(',')

  //To convert patientNameArr into PatientsRegister Type Object
  const occurrences = patientNameArr.reduce(function (acc: any, curr) {
    return acc[curr] ? ++acc[curr] : acc[curr] = 1, acc
  }, {}) 

  const getQuaratine = new Quarantine(occurrences)
  getQuaratine.setDrugs(drugNames.split(','))

  const showResult = () => {
    const report = getQuaratine.report()
    setSimulationResult(JSON.stringify(report))
    setPatientOutputState(patientOutputState => [...patientOutputState, JSON.stringify(report)])
    showSimulationRecord(true)
  }

  const patientInput = patientInitialState.map((patient) => {
    return <li>{patient}</li>
  })
  
  
  const patientOutput = patientOutputState.map((patient) => {
    if(JSON.stringify(patient) !== '{}') {
      return <li>{JSON.stringify(patient)}</li>
    }
  })

 
  return (
    <div className="App">
      <header className="App-header">
       Hospital Simulation System 
      </header>
      <div className="content">
        <h2>PATIENT & DRUGS DATA</h2>
        <p>
          <span>Click the button to see current patients and drugs in the Hospital:</span>
          <button data-testid='getData' onClick={() => getData()}>Click Here!!</button>
        </p>
        {patientsRegister !== '' && 
          <p>
            <span data-testid='patientData'>Patients are:</span>&nbsp;&nbsp; {patientsRegister} <br />
          Drug Names are:&nbsp;&nbsp; {drugNames === '' ? 'No Drugs Available' : drugNames}</p>
        }
        
        {drugNames !== '' ? 
          <>
            <h2 className='mTop-90'>SIMULATION DATA</h2>
            <p>
              {!simulationRecord && <>
                <span>Click the button to see the result of the simulation:</span>
                <button onClick={() => showResult()}>Click Here!!</button><br />
              </>}
              
              {JSON.stringify(simulationResult) !== '{}' && drugNames !== '' && `Simulation Results is: ${simulationResult}`}
            </p>
          </> : 
          <h2 className='mTop-90'>NO SIMULATION DATA</h2>
          }

          {
            patientInitialState.length === 10 && <>
            <h2 className='mTop-90'>LIST OF SIMULATION HISTORY</h2>
            <div className='table'>
              <div className='left-col'>Input Patient State
                <ol>{patientInput}</ol>
              </div>
              <div className='right-col'>Output Patient State
                <ol>{patientOutput}</ol>
              </div>
            </div>
            </>
          }
      </div>
    </div>
  );
}

export default App;
