export const STUDENTS = [
    {
        name: 'John',
        validityDate: '2030-12-30'
    },
    {
        name: 'Jane',
        validityDate: '2030-05-25'
    },
    {
        name: 'Adam',
        validityDate: '2030-11-11'
    },
    {
        name: 'Bonnie',
        validityDate: '2008-11-11'
    },
    {
        name: 'Dhilip',
        validityDate: '2030-12-30'
    },
    {
        name: 'Falude',
        validityDate: '2020-05-25'
    },
    {
        name: 'Damiyen',
        validityDate: '2030-11-11'
    },
    {
        name: 'Talisk',
        validityDate: '2023-11-11'
    }
];